//Array(Arreglo) para las imagenes, aquí van a poner las imagenes//
// de cada uno ( ES INDIVIDUAL) //

//fotos de Unsplash (ajustadas con w=400&h=300&fit=crop)//

const imagenes = [
  "https://images.pexels.com/photos/1032650/pexels-photo-1032650.jpeg",
  "https://images.pexels.com/photos/240526/pexels-photo-240526.jpeg",
  "https://images.pexels.com/photos/67566/palm-tree-palm-ocean-summer-67566.jpeg",
  "https://images.pexels.com/photos/1710795/pexels-photo-1710795.jpeg",
  "https://images.pexels.com/photos/1078983/pexels-photo-1078983.jpeg",
  "https://images.pexels.com/photos/66258/staniel-cay-swimming-pig-seagull-fish-66258.jpeg"
];

//Seleccion de elementos // 

const boton = document.getElementById("btn-cambiar");
const imagenCard = document.getElementById("card-img");
const textoCard = document.getElementById("card-text");

//contador de las imagenes//

let indice = 0;

//evento del click//
boton.addEventListener("click", () => {
 
 //lo siguiente es para que avance la foto //
  indice++;

//el siguiente if es para que cuando llegue al final se regrese al inicio//
  
  if (indice >= imagenes.length) {
    indice = 0;
  }
      // Cambiar imagen y texto //
imagenCard.src = imagenes[indice];
  textoCard.textContent = `Mostrando imagen ${indice + 1} de ${imagenes.length}`;
});